const headers = Object.keys(table[0])
console.log(headers)

const tableElement = document.createElement('table')
const tHead = document.createElement('thead')

document.querySelector('#wrapper').appendChild(tableElement)
tableElement.appendChild(tHead)

headers.forEach(header => {
    const td = document.createElement('td')
    td.innerText = header
    tHead.appendChild(td)
})

table.forEach(row => {
    const tr = document.createElement('tr')
    tableElement.appendChild(tr)

    headers.forEach(header => {
        const td = document.createElement('td')
        td.innerText = row[header]
        tr.appendChild(td)
    })
})